require(['js/modules'],
    function() {
        'use strict';

        angular.bootstrap(document, ['app','ngTouch']);
    }
);